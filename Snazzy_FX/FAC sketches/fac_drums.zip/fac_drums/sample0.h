#ifndef sample0_header
#define sample0_header

#include <avr/pgmspace.h>

#define sample0_size 1628
#define sample0_fs_micro 0.0300f

extern prog_uchar sample0_data[sample0_size];

#endif
