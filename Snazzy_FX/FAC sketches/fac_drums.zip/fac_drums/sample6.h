#ifndef sample6_header
#define sample6_header

#include <avr/pgmspace.h>

#define sample6_size 1632
#define sample6_fs_micro 0.0240f

extern prog_uchar sample6_data[sample6_size];

#endif
