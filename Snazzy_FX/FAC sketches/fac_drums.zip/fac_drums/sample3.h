#ifndef sample3_header
#define sample3_header

#include <avr/pgmspace.h>

#define sample3_size 1632
#define sample3_fs_micro 0.0240f

extern prog_uchar sample3_data[sample3_size];

#endif
