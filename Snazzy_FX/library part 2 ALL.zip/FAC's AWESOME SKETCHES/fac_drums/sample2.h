#ifndef sample2_header
#define sample2_header

#include <avr/pgmspace.h>

#define sample2_size 1520
#define sample2_fs_micro 0.0240f

extern prog_uchar sample2_data[sample2_size];

#endif
