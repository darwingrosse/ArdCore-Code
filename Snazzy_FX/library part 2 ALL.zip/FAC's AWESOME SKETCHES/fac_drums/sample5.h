#ifndef sample5_header
#define sample5_header

#include <avr/pgmspace.h>

#define sample5_size 1632
#define sample5_fs_micro 0.0220f

extern prog_uchar sample5_data[sample5_size];

#endif
