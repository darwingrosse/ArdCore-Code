#ifndef SINE_TABLE_HEADER
#define SINE_TABLE_HEADER

extern signed char sine_wave[1025];

#endif
